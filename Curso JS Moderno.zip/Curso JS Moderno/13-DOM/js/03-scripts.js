//getElementById
//solo selecciona el primero que encuentre con ese id, si es que en caso hubieran varios

const formulario = document.getElementById('formulario');
console.log(formulario);