//querySelectorAll
//selecciona todos

const card = document.querySelectorAll('.card');
console.log(card);

const formulario = document.querySelectorAll('#formulario');
console.log(formulario);

//cuando no existe
const noExiste = document.querySelectorAll('no-existe');
console.log(noExiste);