//traversing the dom
const navegacion = document.querySelector('.navegacion');
console.log(navegacion.firstElementChild);//primer elemento del nav
console.log(navegacion.lastElementChild);//ultimo elemento del nav

console.log(navegacion.childNodes);// los espacios en blanco son considerados elementos
console.log(navegacion.children);// solo toma los elementos

console.log(navegacion.children[1].nodeName);
console.log(navegacion.children[1].nodeType);

const card = document.querySelector('.card');

card.children[1].children[1].textContent = 'Nuevo text desde traversing';
card.children[0].src = 'img/hacer4.jpg';

console.log(card.children[0]);

//Traversing del hijo al padre
console.log(card.parentNode);
console.log(card.parentElement.parentElement.parentElement); //esto es mas recomendado

console.log(card);
console.log(card.nextElementSibling);//para ir al siguiente elemento
console.log(card.nextElementSibling.nextElementSibling);
console.log(card.previousElementSibling);//para ir al anterior elemento