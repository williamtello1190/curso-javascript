//cambiando el css con javascript
const encabezado = document.querySelector('h1');

encabezado.style.backgroundColor = 'red';
encabezado.style.fontFamily = 'Arial';
encabezado.style.textTransform = 'uppercase';

const card = document.querySelector('.card');
//se puede agregar una nueva clase al card
card.classList.add('nueva-clase');
console.log(card.classList);
