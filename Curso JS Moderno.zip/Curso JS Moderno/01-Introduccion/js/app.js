//alert('hola mundo');

//variable constante
const nombre = prompt('cual es tu nombre?');

//toma el nombre y lo muestra en pantalla
document.querySelector('.contenido').innerHTML = `${nombre} esta aprendiendo javascript moderno`;

//asigna el valor hacia la variable producto
const producto = 'Monitor de 24 pulgadas';

//consola
console.log('log');
console.error('error');
console.time('hola');
console.warn('eso no esta permitido');
console.timeEnd('hola');

//punto y coma
