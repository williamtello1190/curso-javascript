//arrow functions
const aprendiendo = function(){
    console.log('Aprendiendo JS');
}

//sintaxis arrow functions
//tiene return por defrect, si el codigo es de una linea, las llaves son opcionales.
const aprendiendo2 = () => 'Aprendiendo JS';

console.log(aprendiendo2());