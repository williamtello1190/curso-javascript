//ventajas de arrow functions
const aprendiendo = function(tecnologia, tecnologia2){
    console.log(`Aprendiendo ${tecnologia} y ${tecnologia2}`);
}

aprendiendo('Javascript', 'nodeJS');

//sintaxis arrow functions
//tiene return por defrect, si el codigo es de una linea, las llaves son opcionales
//los parentesis son opcionolaes si tiene un parametro
//const aprendiendo2 = (tecnologia, tecnologia2) => `Aprendiendo ${tecnologia} y ${tecnologia2}`;
const aprendiendo2 = tecnoclogia => 'Aprendiendo JS';
console.log(aprendiendo2('Javascript'));