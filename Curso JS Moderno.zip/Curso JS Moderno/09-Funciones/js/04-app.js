//Diferencia entre función y método

const numero1 = 20;
const numero2 = '20';

console.log(parseInt(numero2)); //esto es una función
console.log(numero1.toString()); //esto es un método