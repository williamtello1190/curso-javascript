//parametros por default
//tomar valores por default para la funcion
function saludar(nombre = '', apellido = ''){ 
    console.log(`Hola ${nombre} ${apellido}`)
}

saludar('william');

