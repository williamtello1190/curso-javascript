//funciones nativas de javascript
alert('hubo un error..');

prompt('cual es tu edad?');

console.log(parseInt('20'));