//Arrow function en un foreach y map

const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]


// const nuevoArreglo = carrito.map(function(producto){
//     return `${producto.nombre} - Precio : ${producto.precio}`;
// });

//con arrow function
const nuevoArreglo = carrito.map( producto => `${producto.nombre} - Precio : ${producto.precio}` );
// const nuevoArreglo2 = carrito.forEach(function(producto){
//     return `${producto.nombre} - Precio : ${producto.precio}`;
// });

//con arrow function
const nuevoArreglo2 = carrito.forEach( producto =>{
    console.log(`${producto.nombre} - Precio : ${producto.precio}`);
});

console.log(nuevoArreglo);
