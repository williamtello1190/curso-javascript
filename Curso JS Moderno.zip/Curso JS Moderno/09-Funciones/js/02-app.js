//diferencias de Function Declaration y Function Expression

//Declaración de Función (Function Declaration)
sumar();//si se ejecutara
function sumar(){
    console.log( 2 + 2 );
}


//Expresión de Función (Function Expression)
sumar2();//no se ejecutara
const sumar2 = function(){
    console.log( 3 + 3 );
}

