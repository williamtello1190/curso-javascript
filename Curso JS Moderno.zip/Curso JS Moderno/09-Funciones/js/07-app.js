//como se comunican las funciones

inciapApp();

function inciapApp(){
    console.log('Iniciando app...');
    segundaFunction();
}

function segundaFunction(){
    console.log('Desde la segunda función');
    usuarioAutenticado('William');
}

function usuarioAutenticado(usuario){
    console.log('Autenticando usuario...');
    console.log(`Usuario autenticado exitosamente: ${usuario}`);
}
