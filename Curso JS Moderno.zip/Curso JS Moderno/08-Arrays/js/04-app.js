const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio'];

//modifica la informacion
meses[0] = 'nuevo mes';

//agrega informacion - si no existe el indice lo agrega
meses[10] = 'ultimo mes';

console.table(meses);