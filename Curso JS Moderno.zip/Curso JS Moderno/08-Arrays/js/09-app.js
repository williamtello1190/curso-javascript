const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

for(let i=0;i<carrito.length;i++){
    console.log(`${carrito[i].nombre} - Precio : ${carrito[i].precio}`);
};

carrito.forEach(function(producto){
    console.log(`${producto.nombre} - Precio : ${producto.precio}`)
});
