const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

// //foreach
// carrito.forEach(function(producto){
//     console.log(`${producto.nombre} - Precio : ${producto.precio}`)
// });

// //map .map te crea un arreglo nuevo
// carrito.map(function(producto){
//     console.log(`${producto.nombre} - Precio : ${producto.precio}`)
// });


const nuevoArreglo = carrito.map(function(producto){
    return `${producto.nombre} - Precio : ${producto.precio}`;
});

//foreach no te crea un arreglo nuevo
const nuevoArreglo2 = carrito.forEach(function(producto){
    return `${producto.nombre} - Precio : ${producto.precio}`;
});

console.log(nuevoArreglo);
console.log(nuevoArreglo2);

