const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

// const nombre = producto.nombre;
// console.log(nombre);

//destructuring
const {nombre, precio, disponible} = producto;

console.log(precio);

//destructuring con arreglos
const numeros = [10,20,30,40,50];
// const [primero, segundo, tercero]=numeros;
// console.log(primero);
// console.log(tercero);

// const [ , , , , quinto]=numeros;
// console.log(quinto); 

const [primero, ...tercero] = numeros;
console.log(tercero);

