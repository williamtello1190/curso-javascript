//forma declarativa

const carrito = [];

//definir un producto
const producto = {
    nombre: 'televisor',
    precio: 400
}

const producto2 = {
    nombre: 'celular',
    precio: 800
}

const producto3 = {
    nombre: 'teclado',
    precio: 200
}

let resultado;

resultado = [...carrito, producto2];
resultado = [producto,...resultado];
console.table(resultado);