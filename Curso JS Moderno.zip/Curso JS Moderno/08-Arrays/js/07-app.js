//forma imperativa

const carrito = [];

//definir un producto
const producto = {
    nombre: 'televisor',
    precio: 400
}

const producto2 = {
    nombre: 'celular',
    precio: 800
}

//.push agrega al final de un arreglo
carrito.push(producto);
carrito.push(producto2);

const producto3 = {
    nombre: 'teclado',
    precio: 200
}

//.unshift agrega al principio de un arreglo
carrito.unshift(producto3);

console.table(carrito);

//eliminar el ultimo elemento de un array
carrito.pop();
console.table(carrito);

//eliminar el primero elemento de un array
carrito.shift();
console.table(carrito);

//elimina el elemento enviado en el parametro
//por ejemplo elimanara desde el index 1 hasta el 2
carrito.splice(1,2);
