let resultado;

resultado = Math.round(2.2);
resultado = Math.round(2.6);
resultado = Math.round(2.5);
resultado = Math.round(2.4);

//redondear hacia arriba
resultado = Math.ceil(2.1);

//redondear hacia abajo
resultado = Math.floor(2.9);

//raiz cuadrada
resultado = Math.sqrt(144);

//absoluto
resultado = Math.abs(-500);

//potencia
resultado = Math.pow(2,4);

//minimo
resultado = Math.min(2,1,0,-1);

//maximo
resultado = Math.max(2,1,0,-1);

//aleatorio
resultado = Math.random();

//aleatorio por rango
resultado = Math.floor(Math.random() * 30);

console.log(resultado);
