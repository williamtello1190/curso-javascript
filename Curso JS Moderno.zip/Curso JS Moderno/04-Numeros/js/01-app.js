const numero1 = 20;
const numero2 = 30;

console.log(numero1);
console.log(numero2);