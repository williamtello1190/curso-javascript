let puntaje = 5;

puntaje += 3;
puntaje -= 2;

console.log(puntaje);