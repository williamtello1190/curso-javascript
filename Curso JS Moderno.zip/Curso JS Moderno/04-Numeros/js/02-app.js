const numero1 = 30;
const numero2 = 20;

//suma
let suma = numero1 + numero2;
console.log(suma);

//resta
let resta = numero1 - numero2;
console.log(resta);

//multiplicacion
let multiplicacion = numero1 * numero2;
console.log(multiplicacion);

//division
let division = numero1 / numero2;
console.log(division);

//modulo
let modulo = numero1 % numero2;
console.log(modulo);