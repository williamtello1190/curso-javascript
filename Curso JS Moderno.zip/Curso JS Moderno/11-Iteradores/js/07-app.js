//for of  .. recorre arreglo
const pendientes = ['Tarea', 'Comer', 'Proyecto', 'Estudiar Javascript'];

const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

for (pendiente of pendientes){
    console.log(pendiente);
}

for (producto of carrito){
    console.log(producto.nombre);
}
