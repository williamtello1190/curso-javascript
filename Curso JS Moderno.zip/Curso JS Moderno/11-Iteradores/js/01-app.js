//for loop

for(let i = 1; i <= 20; i++){
    if(i%2==0){
        console.log(`el numero ${i} es par`);
    }
    else{
        console.log(`el numero ${i} es impar`);
    }
}

const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

 for(let i = 0; i < carrito.length; i++){
    console.log(carrito[i].nombre);
 }