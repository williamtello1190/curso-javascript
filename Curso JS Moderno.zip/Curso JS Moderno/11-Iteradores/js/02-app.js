//break y continue en for loop

//continue rompe el ciclo, no va a continuar en la siguiente linea si no vuelve a rercorrer
//break rompe el ciclo y sale del recorrido

// for(let i = 0; i <= 10; i++){
//     if(i === 5){
//         console.log('CINCO');
//         continue;
//     }
//     console.log(`numero:  ${i}`);
// }

const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 , descuento : true},
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

for(let i = 0; i < carrito.length; i++){
    if(carrito[i].descuento){
        console.log(`El articulo ${carrito[i].nombre} tiene descuento`);
        continue;
    }
    console.log(carrito[i].nombre);
}

