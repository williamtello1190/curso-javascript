//foreach y map

const pendientes = ['Tarea', 'Comer', 'Proyecto', 'Estudiar Javascript'];

pendientes.forEach((pendiente,indice)=>{
    console.log(`${indice} : ${pendiente}`);
});

const carrito = [
    { nombre:'Televisor', precio:200 },
    { nombre:'Tablet', precio:300 },
    { nombre:'Audifonos', precio:100 },
    { nombre:'Teclado', precio:150 },
    { nombre:'Celular', precio:800 }
]

const nArreglo = carrito.forEach(producto => producto.nombre);
const nArreglo2 = carrito.map(producto => producto.nombre);
//foreach no crea un nuevo arreglo, map si
console.log(nArreglo);
console.log(nArreglo2);