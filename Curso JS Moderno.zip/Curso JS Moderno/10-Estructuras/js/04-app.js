//mayor e igual y else if

const dinero = 100;
const totalAPagar = 200;
const tarjeta = true;
const cheque = false;

if(dinero > totalAPagar){
    console.log('si podemos pagar');
} else if(tarjeta){
    console.log('si puedo pagar con tarjeta');
} 
else if(cheque){
    console.log('si puedo pagar con cheque');
} 
else{
    console.log('fondos insuficientes');
}
