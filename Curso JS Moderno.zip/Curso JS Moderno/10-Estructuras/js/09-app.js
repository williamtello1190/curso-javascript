//operador ternario
const autenticado = true;
const puedePagar = true;

console.log(autenticado ? puedePagar ? 'si esta autenticado y puede pagar' : 'si esta autenticado, no puede pagar' : 'no no esta autenticado');