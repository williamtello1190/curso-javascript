//if

const puntaje = 1002;

if(puntaje == 1000){
    console.log('si es igual..');
}else{
    console.log('no es igual..');
}