//operador mayor que y menor que

const dinero = 300;
const totalAPagar = 200;

if(dinero > totalAPagar){
    console.log('si podemos pagar');
} else{
    console.log('fondos insuficientes');
}

// > mayor a
// < menor a
// >= mayor e igual a
// <= menor e igual a