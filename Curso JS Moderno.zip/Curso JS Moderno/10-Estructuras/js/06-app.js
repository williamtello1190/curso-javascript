// && and 

const usuario = false;
const puedePagar = false;

if(usuario && puedePagar){
    console.log('si puedes comprar');
} else if(!usuario && !puedePagar){
    console.log('no puedes comprar');
} else if(!usuario){
    console.log('inicio session o abre una cuenta');
} else if(!puedePagar){
    console.log('fondos insuficientes');
}


