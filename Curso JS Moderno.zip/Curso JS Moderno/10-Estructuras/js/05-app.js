// switch case

const metodoPago = 'cheque';

switch(metodoPago){
    case 'efectivo':
        pagar();
        break;
    case 'cheque':
        console.log(`Pagaste con ${metodoPago}`);
        break;
    case 'tarjeta':
        console.log(`Pagaste con ${metodoPago}`);
        break;
    default:
        console.log('Aún no haz seleccionado un método de pago o no soporta');
}

function pagar(){
    console.log('Pagando...');
}