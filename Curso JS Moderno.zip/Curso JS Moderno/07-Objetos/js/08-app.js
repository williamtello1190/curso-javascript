'use strict';
const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

//congelar
//con freeze no nos permitira modificar, eliminar o agregar algo al objeto conteniendo primero el use strict
Object.freeze(producto);
 delete producto.precio;producto;

//producto.disponible = false;
console.log(producto);

//para ver si esta congelado
console.log(Object.isFrozen(producto));