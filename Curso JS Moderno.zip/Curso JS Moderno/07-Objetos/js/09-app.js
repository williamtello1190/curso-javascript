'use strict';
const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

//sellado
//con seal no nos permitira eliminar y agregar un atributo, pero si modificar el objeto conteniendo primero el use strict
Object.seal(producto);

producto.precio = 500;

//producto.disponible = false;
console.log(producto);

//para comprobar si esta sellado el objeto
console.log(Object.isSealed(producto));