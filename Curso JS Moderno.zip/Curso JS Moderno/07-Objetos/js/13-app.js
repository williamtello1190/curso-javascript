const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

//keys - te retorna los nombres de los atributos, sus llaves
console.log(Object.keys(producto));

//values - te retorna los valores de los atributos del objeto
console.log(Object.values(producto));

//entries - te retorna todo completo
console.log(Object.entries(producto));