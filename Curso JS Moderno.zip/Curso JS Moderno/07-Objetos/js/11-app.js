//this para llamar al atributo dentro del objeto 

const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true,
    mostrarInfo:function(){
        console.log(`El producto ${this.nombre} tiene un precio de ${this.precio}`)
    }
}

const producto2 = {
    nombre:'tablet',
    precio:500,
    disponible:true,
    mostrarInfo:function(){
        console.log(`El producto ${this.nombre} tiene un precio de ${this.precio}`)
    }
}

producto.mostrarInfo();
producto2.mostrarInfo();