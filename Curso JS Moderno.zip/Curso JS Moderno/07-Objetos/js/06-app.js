const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true,
    informacion:{
        peso: '1kg',
        medida: '3m'
    },
    fabricacion:{
        pais: 'China'
    }
}

const {nombre, informacion, informacion: { fabricacion, fabricacion: { pais }}} = producto;

console.log(nombre);
console.log(informacion);
// console.log(pais);
// console.log(producto.informacion);
// console.log(producto.informacion.peso);
console.log(fabricacion);
console.log(pais);