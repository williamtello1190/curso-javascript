const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

const medidas = {
    peso:'1kg',
    medida:'1m'
}

console.log(producto);
console.log(medidas);

//assign para unir dos objetos
const resultado = Object.assign(producto, medidas);
console.log(resultado);

//spread operator o rest operator
//sirve tmb para sacar una copia a los objetos y unirlo
const resultado2 = { ...producto, ...medidas}
console.log(resultado2);
