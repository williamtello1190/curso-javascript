const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

//agregar nuevas propiedades al objeto
producto.imagen = 'img.jpg';

//eliminar propiedad del objeto
delete producto.disponible;

console.log(producto);