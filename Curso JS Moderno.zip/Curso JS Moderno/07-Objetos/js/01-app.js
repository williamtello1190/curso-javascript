const nombre = 'monitor';
const precio = 300;
const disponible = true;

//un objeto agrupa todo en una sola variable

//object literal
const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true
}

console.log(producto);