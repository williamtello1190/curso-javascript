const producto = {
    nombre:'monitor',
    precio:300,
    disponible:true,
    informacion:{
        peso:'1kg',
        medida:'3m'
    },
    fabricacion:{
        pais:'China'
    }
}

console.log(producto);
console.log(producto.informacion);
console.log(producto.informacion.peso);
console.log(producto.fabricacion);