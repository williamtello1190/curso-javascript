//Varialbles
const resultado = document.querySelector('#resultado');
const year = document.querySelector('#year');

const max = new Date().getFullYear();
const min = max - 10;

const marca = document.querySelector('#marca');
const minimo = document.querySelector('#minimo');
const maximo = document.querySelector('#maximo');
const puertas = document.querySelector('#puertas');
const transmision = document.querySelector('#transmision');
const color = document.querySelector('#color');

let datosBusqueda = {
    marca:'',
    minimo:'',
    maximo:'',
    puertas:'',
    transmision:'',
    color:'',
}

marca.addEventListener('change', e => {
    
    datosBusqueda.marca = e.target.value;
    filtrarAuto();
});

year.addEventListener('change', e => {
    
    datosBusqueda.year = ParseInt(e.target.value);
    filtrarAuto();
});

minimo.addEventListener('change', e => {
    
    datosBusqueda.minimo = e.target.value;
    filtrarAuto();
});

maximo.addEventListener('change', e => {
    
    datosBusqueda.maximo = e.target.value;
    filtrarAuto();
});

puertas.addEventListener('change', e => {
    
    datosBusqueda.puertas = ParseInt(e.target.value);
    filtrarAuto();
});

transmision.addEventListener('change', e => {
    
    datosBusqueda.transmision = e.target.value;
    filtrarAuto();
});

color.addEventListener('change', e => {
    
    datosBusqueda.color = e.target.value;
    filtrarAuto();
});

//Inicio
document.addEventListener('DOMContentLoaded', () => {
    mostrarAutos();
    llenarSelect();//llenamos el select de los años
});

//Funciones
function mostrarAutos() {
    console.log('iniciando');
}

function llenarSelect(){
    
    for (let i = max; i >= min;  i--) {
        const anio = document.createElement('option');
        anio.value = i;
        anio.text = i;
        year.appendChild(anio);
    }
    
}

function filtrarAuto(){
     const result = autos.filter(filtrarMarca).filter(filtrarYear);
     console.log(result);
}

function filtrarMarca(auto){
    const {marca} = datosBusqueda;
    if(marca){
        auto.marca === marca;
        return;
    }
    return auto;
}

function filtrarYear(auto){
    const {year} = datosBusqueda;
    if(year){
        auto.year === year;
        return;
    }
    return auto;
}

function filtrarMinimo(auto){
    const {minimo} = datosBusqueda;
    if(minimo){
        auto.precio >= minimo;
        return;
    }
    return auto;
}

function filtrarMaximo(auto){
    const {maximo} = datosBusqueda;
    if(maximo){
        auto.precio <= maximo;
        return;
    }
    return auto;
}

function filtrarPuertas(auto){
    const {puertas} = datosBusqueda;
    if(puertas){
        auto.puertas === puertas;
        return;
    }
    return auto;
}

function filtrarTransmision(auto){
    const {transmision} = datosBusqueda;
    if(transmision){
        auto.transmision === transmision;
        return;
    }
    return auto;
}

function filtrarColor(auto){
    const {color} = datosBusqueda;
    if(color){
        auto.auto === color;
        return;
    }
    return auto;
}
