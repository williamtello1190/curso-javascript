//undefined
let numero;

console.log(numero);
//console.log(typeof numero);

//null
let numero2 = null;
console.log(numero2);
console.log(typeof numero2);

console.log(numero === numero2);
