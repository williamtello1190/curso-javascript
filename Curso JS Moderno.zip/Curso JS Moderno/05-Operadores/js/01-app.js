const numero1 = 20;
const numero2 = '20';
const numero3 = 30;

//operador mayor a..
console.log(numero1 > numero3);
console.log(numero3 > numero1);

//operador menor a..
console.log(numero1 < numero3);  