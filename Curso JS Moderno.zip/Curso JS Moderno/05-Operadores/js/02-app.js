const numero1 = 20;
const numero2 = '20';
const numero3 = 30;

//si 2 numeros son iguales
console.log(numero1 == numero3);
console.log(numero1 == numero2);

//comparador estricto
console.log(numero1 === numero2);
console.log(numero1 == parseInt(numero2));
console.log(typeof numero1);
console.log(typeof numero2);

//diferente
const paswoord1 = 'admin';
const password2 = 'Admin';

console.log(paswoord1 != password2);
console.log(numero1 != numero2);
console.log(numero1 !== parseInt(numero2));