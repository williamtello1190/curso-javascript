//every : todos los elementos del array debe cumplir para q retornme true
const carrito = [
    { nombre: 'Monitor 27 Pulgadas', precio: 500 },
    { nombre: 'Televisión', precio: 100 },
    { nombre: 'Tablet', precio: 200 },
    { nombre: 'Audifonos', precio: 300 },
    { nombre: 'Teclado', precio: 400 },
    { nombre: 'Celular', precio: 100 },
]

//debe cumplir en todo el array para devolver true
const resultado = carrito.every(producto => producto.precio < 500);
console.log(resultado);

//con que encuentre en uno devolvera true
const resultado2 = carrito.some(producto => producto.precio < 500);
console.log(resultado2);