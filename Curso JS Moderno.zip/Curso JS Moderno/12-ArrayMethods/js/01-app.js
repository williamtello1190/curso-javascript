//includes y some

const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio'];

const carrito = [
    { nombre: 'Monitor 27 Pulgadas', precio: 500 },
    { nombre: 'Televisión', precio: 100 },
    { nombre: 'Tablet', precio: 200 },
    { nombre: 'Audifonos', precio: 300 },
    { nombre: 'Teclado', precio: 400 },
    { nombre: 'Celular', precio: 700 },
]

//includes y some retornar un booleano

// Comprobar si un valor existe en un arreglo -- metodo como se haria con un foreach
// meses.forEach(mes=>{
//     if(mes === 'Enero'){
//         console.log('Enero si existe');
//     }
// });

//usando .includes - se usa en arreglo de indices
const resultado = meses.includes('Diciembre');
console.log(resultado);

//usando .some - se usa en un arreglo de objetos
const existe = carrito.some(producto => producto.nombre === 'Monitor curvo');
console.log(existe);

//En un arreglo tradicional tmb se puede usar . some
const existe2 = meses.some(mes => mes === 'Enero');
console.log(existe2);

