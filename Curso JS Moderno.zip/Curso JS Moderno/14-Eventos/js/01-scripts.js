//detectar cuando el html esta listo

 console.log(1);

 document.addEventListener('DOMContentLoaded',()=>{
    console.log(2);
 });
 
 console.log(3);
