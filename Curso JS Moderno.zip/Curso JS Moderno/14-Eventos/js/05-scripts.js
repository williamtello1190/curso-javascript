//eventos al dar scroll con el mouse
window.addEventListener('scroll',()=>{
    // const scrollPX = window.scrollY;
    // console.log(scrollPX);// para ver los pixeles y si estamos scrolleando hacia abajo o arriba

    const premium = document.querySelector('.premium');
    const ubicacion = premium.getBoundingClientRect();//detecta donde esta el elemento
    //console.log(ubicacion);
    if(ubicacion.top < 784){
        console.log('el elemento ya esta visible');
    }else{
        console.log('aun no, da mas scroll');
    }

});
