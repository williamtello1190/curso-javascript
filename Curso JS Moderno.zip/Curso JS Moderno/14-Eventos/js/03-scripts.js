//Eventos sobre los inputs

const busqueda = document.querySelector('.busqueda');

busqueda.addEventListener('input', (e) =>{
    if(e.target.value === ''){
        console.log('fallo la validacion');
    }else{
        console.log(e.target.value);
    }
})

//keyup - cuando sueltas lo que esta escribiendo
//keydown - cuando estas escribiendo
//blur - cuando entras al salir ejecuta
//copy - copiar
//paste - pegar
//cut - cortar
//input - todo en uno
//e - evento
