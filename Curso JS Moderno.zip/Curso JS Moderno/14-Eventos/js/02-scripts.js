//Eventos con el mouse

const nav = document.querySelector('.navegacion');

nav.addEventListener('mouseenter',()=>{
    console.log('entrando en la navegación');
});

nav.addEventListener('mouseout',()=>{
    console.log('saliendo de la navegación');
});

nav.addEventListener('dblclick',()=>{
    console.log('doble click de la navegación');
});

//mousedown - similar al click
//click
//dblclick - doble click
//mouseup - cuando sueltas el mouse
