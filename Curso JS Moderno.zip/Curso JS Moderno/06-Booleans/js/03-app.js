const auntenticado = true;

// if(auntenticado){
//     console.log('si esta autenticado');
// }
// else{
//     console.log('no esta autenticado');
// }

console.log(auntenticado ? 'si esta' : 'no esta');