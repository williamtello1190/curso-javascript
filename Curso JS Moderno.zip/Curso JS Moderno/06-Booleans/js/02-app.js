const boolean1 = true;
const boolean2 = false;

console.log(boolean1 === boolean2);

console.log(boolean1 === true);
console.log(boolean1 === 'true');