//let cumple mayor mente como el var
// let producto = 'Tablet';
