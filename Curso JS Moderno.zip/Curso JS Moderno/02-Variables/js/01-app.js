// //inicializar una variable con un valor
// var producto = "Monitor de 24 pulgadas";
// console.log(producto);

// //las variables se puede reasignar 
// producto = 'monitor de 19 Pulgadas';
// console.log(producto);

// //javascript es unlenguaje de tipo dinamico, no se especifica tipo de dato
// producto = 20;
// console.log(producto);

// //Se pueden inicializar sin valor y asignarlo despues
// var disponible;
// disponible = true;
// disponible = false;

// //inicializar multiples variables
// var categoria = 'Computadoras',
//     marca = 'Marca',
//     calificacion = 5;

// //los nombres de variable no pueden iniciar con numero
// //var 99dias;
// var dias99;

// //lo mas recomendado es q sea camelcase, q inicie con minuscula
// var nombreProducto;
