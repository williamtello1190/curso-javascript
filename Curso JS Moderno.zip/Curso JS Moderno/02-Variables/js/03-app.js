//const no se pueden reasignar y deben tener un valor
const producto = 'tablet';
console.log(producto);