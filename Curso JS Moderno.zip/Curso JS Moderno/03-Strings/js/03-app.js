//concatenar
const producto = 'Monitor 20 Pulgadas ';
const precio = '30 USD';

console.log(producto.concat(precio));
console.log(producto.concat('En descuento'));
console.log("el producto " + producto + "tiene un precio de " + precio);
console.log("el producto ", producto , "tiene un precio de " , precio);
console.log(`el producto ${producto}`);
