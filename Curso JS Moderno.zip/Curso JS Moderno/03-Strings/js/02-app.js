const producto = 'Monitor 20';
console.log(producto);

//conocer la cantidad de letras de la cadena de texto
console.log(producto.length);

//obtener la posicion en la cadena del string
console.log(producto.indexOf('Monitor'));

//si incluye la palabra dentro de la cadena
console.log(producto.includes('Monitor'));
