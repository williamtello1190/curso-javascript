const producto = 'Monitor de 20 pulgadas';
const producto2 = String('Monitor de 24 pulgadas');
const producto3 = new String('Monitor de 27 pulgadas');

console.log(producto);
console.log(producto2);
console.log(producto3);