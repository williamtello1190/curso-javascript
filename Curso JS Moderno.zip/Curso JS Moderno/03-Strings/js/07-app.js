const producto = 'Monitor de 20 pulgadas';
//mayusculas
console.log(producto.toUpperCase());

//minusculas
console.log(producto.toLowerCase());

//convertir a string
const precio = 300;
console.log(precio);
console.log(precio.toString());