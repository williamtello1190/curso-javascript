const producto = '          Monitor de 20 pulgadas          ';
console.log(producto);
console.log(producto.length);

//eliminar los espacios al inicio
console.log(producto.trimStart());

//eliminar los espacios al final
console.log(producto.trimEnd());

//eliminar espacios en ambos lados
console.log(producto.trim());