const producto = 'Monitor de 20 pulgadas';
console.log(producto);

//.repeat te va a permitir repetir una cadena de texto
const texto = ' en promoción'.repeat(2);
console.log(texto);
console.log(`${producto} ${texto}`);

//.split
const hobbies = 'leer, caminar, escribir, escuchar';
console.log(hobbies.split(', '))